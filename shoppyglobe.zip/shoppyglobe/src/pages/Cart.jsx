import { useSelector, useDispatch } from "react-redux";
import CartItem from "../components/CartItem";
import { removeFromCart } from "../redux/cartSlice";

const Cart = () => {
  const cartItems = useSelector(state => state.cart);
  const dispatch = useDispatch();

  const handleRemove = (id) => {
    dispatch(removeFromCart(id));
  };

  const totalPrice = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

  if (cartItems.length === 0)
    return <p className="p-4 text-center">Your cart is empty.</p>;

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Shopping Cart</h1>
      <div className="space-y-4">
        {cartItems.map(item => (
          <CartItem key={item.id} item={item} onRemove={() => handleRemove(item.id)} />
        ))}
      </div>
      <div className="mt-6 text-right text-xl font-semibold">
        Total: ₹{totalPrice.toFixed(2)}
      </div>
    </div>
  );
};

export default Cart;
