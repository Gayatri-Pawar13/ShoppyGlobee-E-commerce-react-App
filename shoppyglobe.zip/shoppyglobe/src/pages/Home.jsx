import { useState } from "react";
import useFetchProducts from "../hooks/useFetchProducts";
import ProductItem from "../components/ProductItem";

const Home = () => {
  const { products, error } = useFetchProducts();
  const [query, setQuery] = useState("");

  if (error) return <p className="text-red-600 text-center p-6">{error}</p>;
  if (!products.length) return <p className="text-gray-700 text-center p-6">Loading products...</p>;

  const filtered = products.filter((product) =>
    product.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-100 py-10 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Page Title */}
        <h1 className="text-4xl font-extrabold text-center text-purple-800 mb-6">
          🛍️ Welcome to ShoppyGlobe
        </h1>

        {/* Search Bar */}
        <div className="mb-8 flex justify-center">
          <input
            type="text"
            placeholder="Search products..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full md:w-1/2 p-3 rounded-lg border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filtered.map((product) => (
            <ProductItem key={product.id} product={product} />
          ))}
        </div>

        {/* No products message */}
        {filtered.length === 0 && (
          <p className="text-center text-gray-600 mt-8">No products found.</p>
        )}
      </div>
    </main>
  );
};

export default Home;
