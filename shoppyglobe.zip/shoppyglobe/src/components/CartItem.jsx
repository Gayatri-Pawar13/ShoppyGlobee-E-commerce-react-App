const CartItem = ({ item, onRemove }) => {
  return (
    <div className="flex items-center justify-between border-b py-3">
      <div className="flex items-center gap-4">
        <img src={item.thumbnail} alt={item.title} className="w-20 h-20 object-cover rounded" />
        <div>
          <h2 className="font-semibold">{item.title}</h2>
          <p>Quantity: {item.quantity}</p>
          <p>Price: ₹{item.price}</p>
        </div>
      </div>
      <button
        onClick={onRemove}
        className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
      >
        Remove
      </button>
    </div>
  );
};

export default CartItem;
