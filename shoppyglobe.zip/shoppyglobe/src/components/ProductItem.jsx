import { useDispatch } from "react-redux";
import { addToCart } from "../redux/cartSlice";

const ProductItem = ({ product }) => {
  const dispatch = useDispatch();

  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center text-center hover:shadow-lg transition">
      <img
        src={product.thumbnail}
        alt={product.title}
        className="w-32 h-32 object-cover mb-2 rounded"
      />
      <h3 className="font-semibold text-lg">{product.title}</h3>
      <p className="text-gray-600 text-sm">{product.description.slice(0, 50)}...</p>
      <p className="font-bold mt-2">${product.price}</p>
      <button
        onClick={() => dispatch(addToCart(product))}
        className="mt-3 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
      >
        Add to Cart
      </button>
    </div>
  );
};

export default ProductItem;

